doc = """<script>
h=window.location.protocol+"//",r='<body onload="';
</script>"""
from bs4.diagnose import diagnose
diagnose(doc)
